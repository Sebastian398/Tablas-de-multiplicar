#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

#La funcion from importa los datos necesarios de las librerias
from random import randint, choice, random
import msvcrt
from colorama import Fore
from modules import saludos
from modules import tablas


#Se define la variable generar_tablas()
def generar_tablas():

    #Genera un color aleatorio entre amarillo, azul, rojo y verde
    generar_color = ([Fore.GREEN, Fore.BLUE, Fore.YELLOW, Fore.CYAN, Fore.RED])
    
    #Genera un número aleatorio entre 1 y 20
    dato1 = randint(1, 20)
    
    #La funcion saludo() muestra en pantalla un saludo
    saludos.saludo()
    
    #La función print muestra en pantalla el número de tablas a generar
    print(f"Se generarán las tablas de multiplicar del 1 al {dato1}")
    
    #La funcion multi() crea las tablas de multiplicar
    tablas.multi(dato1)

    #Preguntar al usuario si desea repetir el proceso o cerrar el programa
    print("¿Deseas generar las tablas de multiplicar de nuevo? s/n")
    
    respuesta= None
    
    while respuesta not in ["s", "n"]:
        respuesta  = msvcrt.getwch()
    if respuesta   == "s": 
        generar_tablas()
    elif respuesta == "n":
        print("¡Gracias por usar el programa!")

#Iniciar el programa
if __name__ == "__main__":
    generar_tablas()