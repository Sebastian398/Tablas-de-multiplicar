#La funcion saludo() muestra en pantalla un saludo
def saludo():
    print("Hola ficha 2877795! :)")