#La funcion from importa los datos necesarios de las librerias
from random import randint


#La funcion dividir(dato1, dato2) divide 2 datos almacenados
def dividir(dato1, dato2):
    dato1=randint(0,100)
    dato2=randint(0,100)
    # El condicional if permite verificar si el divisor es cero
    if dato2 == 0:
    #return cumple la funcion de indicar que no se puede dividir por cero
        return "No se puede dividir por 0"
    #else permite realizar la division en caso de que el divisor sea un numero diferente de cero
    else:
        #return devuelve el numero del resultado de la division de dato1 / dato2
        return dato1 / dato2
        print("La division es: ", dividir(dato1, dato2))