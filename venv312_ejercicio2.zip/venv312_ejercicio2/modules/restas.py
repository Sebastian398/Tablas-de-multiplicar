#La funcion from importa los datos necesarios de las librerias
from random import randint


#La funcion restar(dato1, dato2) resta 2 datos almacenados
def restar(dato1, dato2):
    dato1=randint(0,100)
    dato2=randint(0,100)
    #return devuelve el numero del resultado de la resta de dato1 - dato2  
    return dato1 - dato2
    #La funcion print("La resta es: ", restar(dato1, dato2)) muestra en pantalla el resultado de la resta de dato1 - dato2
    print("La resta es: ", restar(dato1, dato2))
