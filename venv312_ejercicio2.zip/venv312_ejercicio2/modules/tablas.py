#La funcion from importa los datos necesarios de las librerias
from colorama import Fore
from random import randint
import random
import msvcrt


#Se define la variable generar_tablas()
def multi(dato1):


    #Genera un color aleatorio entre amarillo, azul, rojo y verde
    generar_color = random.choice([Fore.GREEN, Fore.BLUE,
                                Fore.YELLOW, Fore.CYAN, 
                                Fore.RED])
    
    #La función for designa la tabla de multiplicar del 1 hasta la del número aleatorio
    for tabla in range(1, dato1+1):
            #La función print muestra en pantalla el título de cada tabla de multiplicar
            print(generar_color+f"Tabla de multiplicar del {tabla}")
            
            #La función for itera del 1 al 10 y calcula los resultados
            for i in range(1, 11):
                resultado = tabla * i
                #La función print muestra el resultado de las multiplicaciones de cada tabla
                print(generar_color+f"{tabla} x {i}={resultado}")
            #print("pulse una tecla para continuar") muestra en pantalla la indicacion de pulsar una tecla para seguir con el programa
            print("Pulse una tecla para continuar: ")
            msvcrt.getch()
            #La función print crea un espacio para separar las tablas
            print()